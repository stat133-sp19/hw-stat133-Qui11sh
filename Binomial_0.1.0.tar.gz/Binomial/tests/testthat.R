library(testthat)
library(Binomial)
